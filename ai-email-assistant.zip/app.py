"""
app.py
Streamlit user interface for the AI Email Writing Assistant.
All AI work happens in email_engine.py. This file only handles the screen.
"""

import html
import os

import streamlit as st

import email_engine as engine

st.set_page_config(page_title="AI Email Writing Assistant", page_icon="✉️", layout="wide")

STYLE = """
<style>
.hero {background: linear-gradient(135deg, #0b2545 0%, #13538a 100%); padding: 1.6rem 2rem; border-radius: 14px; margin-bottom: 1.2rem;}
.hero h1 {color: #ffffff !important; margin: 0; padding: 0; font-size: 2rem;}
.hero p {color: #dbe7f5; margin: 0.4rem 0 0 0; font-size: 1.05rem;}
.email-box {background: #ffffff; border: 1px solid #cfdcec; border-left: 5px solid #13538a; border-radius: 10px; padding: 1.2rem 1.4rem; color: #1b2a3a;}
.email-subject {font-weight: 600; color: #0b2545; margin-bottom: 0.8rem; padding-bottom: 0.6rem; border-bottom: 1px solid #e3ecf7;}
.email-body {line-height: 1.7;}
.rtl {direction: rtl; text-align: right;}
.app-footer {text-align: center; color: #6b7c93; padding: 1.5rem 0 0.5rem 0; font-size: 0.9rem;}
</style>
"""

HERO = (
    '<div class="hero"><h1>✉️ AI Email Writing Assistant</h1>'
    "<p>Write professional, clear and effective emails in seconds with AI.</p></div>"
)

FOOTER = '<div class="app-footer">Powered by Groq AI | Built with Python and Streamlit</div>'

FEATURES = [
    "✉️ Generate Email",
    "🛠️ Improve Email",
    "🔄 Rewrite Email",
    "✂️ Shorten Email",
    "📖 Expand Email",
    "🏷️ Subject Lines",
    "↩️ Reply Generator",
]

# ----------------------------------------------------------------------
# Setup helpers
# ----------------------------------------------------------------------
for _key, _default in {"result": None, "last_request": None, "subject_options": None}.items():
    st.session_state.setdefault(_key, _default)


def load_api_key():
    """Streamlit Secrets first (deployment), then an environment variable."""
    try:
        return st.secrets["GROQ_API_KEY"]
    except Exception:
        return os.environ.get("GROQ_API_KEY", "")


@st.cache_resource(show_spinner=False)
def get_client(api_key):
    return engine.get_client(api_key)


def run_task(label, func, **kwargs):
    """Run an engine function with a spinner. Show friendly errors. Return result or None."""
    try:
        client = get_client(load_api_key())
        with st.spinner(label):
            return func(client=client, **kwargs)
    except engine.EmailEngineError as error:
        st.error(str(error))
    except Exception:
        st.error("Something unexpected went wrong. Please try again.")
    return None


def perform(func_name, shown_tone, shown_language, kwargs):
    """Call an email function, then keep the result in session state."""
    func = getattr(engine, func_name)
    result = run_task("Writing your email...", func, **kwargs)
    if result is None:
        return False
    st.session_state.result = {**result, "tone": shown_tone, "language": shown_language}
    st.session_state.last_request = {
        "func": func_name, "tone": shown_tone, "language": shown_language, "kwargs": kwargs,
    }
    return True


def full_text(result):
    if result["subject"]:
        return f"Subject: {result['subject']}\n\n{result['body']}"
    return result["body"]


def safe_html(text):
    return html.escape(text).replace("$", "&#36;").replace("\n", "<br>")


# ----------------------------------------------------------------------
# Results display
# ----------------------------------------------------------------------
def show_result():
    result = st.session_state.result
    if not result:
        return

    st.divider()
    st.subheader("📨 Your Email Draft")
    st.markdown(f"**Tone:** {result['tone']} &nbsp;|&nbsp; **Language:** {result['language']}")

    direction = " rtl" if result["language"] == "Urdu" else ""
    subject_html = safe_html(result["subject"] or "(no subject generated)")
    body_html = safe_html(result["body"])
    st.markdown(
        f'<div class="email-box{direction}"><div class="email-subject">Subject: {subject_html}</div>'
        f'<div class="email-body">{body_html}</div></div>',
        unsafe_allow_html=True,
    )

    st.markdown("**📋 Copy Email:** click the copy icon at the top-right of the box below.")
    st.code(full_text(result), language=None, wrap_lines=True)

    st.markdown("##### Quick actions")
    b1, b2, b3 = st.columns(3)

    if b1.button("🔁 Generate Again"):
        req = st.session_state.last_request
        if req and perform(req["func"], req["tone"], req["language"], req["kwargs"]):
            st.rerun()

    if b2.button("🛠️ Improve Email"):
        kwargs = {"email_text": full_text(result), "language": result["language"]}
        if perform("improve_email", result["tone"], result["language"], kwargs):
            st.rerun()

    if b3.button("✂️ Shorten Email"):
        kwargs = {"email_text": full_text(result), "language": result["language"]}
        if perform("shorten_email", result["tone"], result["language"], kwargs):
            st.rerun()

    t1, t2 = st.columns([2, 1])
    new_tone = t1.selectbox("Change tone to", engine.TONES, key="new_tone")
    t2.markdown("<div style='height: 1.9rem'></div>", unsafe_allow_html=True)
    if t2.button("🎭 Change Tone"):
        kwargs = {"email_text": full_text(result), "tone": new_tone, "language": result["language"]}
        if perform("rewrite_email", new_tone, result["language"], kwargs):
            st.rerun()


# ----------------------------------------------------------------------
# Feature forms
# ----------------------------------------------------------------------
def generate_form():
    with st.form("generate_form"):
        c1, c2 = st.columns(2)
        purpose = c1.selectbox("Email Purpose *", engine.PURPOSES)
        recipient = c2.text_input("Recipient *", placeholder="e.g. Mr. Ahmed Khan, Procurement Manager, ABC Traders")
        sender = c1.text_input("Sender Information (optional)", placeholder="e.g. Sara Malik, Business Development Manager, Nova Solutions")
        subject = c2.text_input("Email Subject (optional)", placeholder="Leave empty and the AI will write one")
        context = st.text_area(
            "Email Context / Main Message *", height=170,
            placeholder="e.g. I submitted a project proposal to a client five days ago and have not received a response. "
                        "I want to send a polite follow-up asking whether they have reviewed it.",
        )
        c3, c4, c5 = st.columns(3)
        tone = c3.selectbox("Tone of Email", engine.TONES, index=0)
        length = c4.radio("Email Length", list(engine.LENGTHS.keys()), index=1, horizontal=True)
        language = c5.selectbox("Language", engine.LANGUAGES, index=0)
        additional = st.text_area(
            "Additional Instructions (optional)", height=90,
            placeholder="e.g. Do not sound pushy. Avoid complicated vocabulary. Include a clear call to action.",
        )
        submitted = st.form_submit_button("✨ Generate Email", type="primary")

    if submitted:
        if not recipient.strip() or not context.strip():
            st.warning("Please fill in the Recipient and the Email Context.")
            return
        kwargs = {
            "purpose": purpose, "recipient": recipient, "sender": sender, "subject": subject,
            "context": context, "tone": tone, "length": length, "language": language,
            "additional": additional,
        }
        perform("generate_email", tone, language, kwargs)


def single_email_form(form_key, button_label, func_name, needs_tone, help_text, box_label):
    st.caption(help_text)
    with st.form(form_key):
        email_text = st.text_area(box_label, height=220)
        c1, c2 = st.columns(2)
        tone = c1.selectbox("Tone", engine.TONES) if needs_tone else None
        language = (c2 if needs_tone else c1).selectbox("Language", engine.LANGUAGES)
        submitted = st.form_submit_button(button_label, type="primary")

    if submitted:
        if not email_text.strip():
            st.warning("Please paste your text first.")
            return
        kwargs = {"email_text": email_text, "language": language}
        if needs_tone:
            kwargs["tone"] = tone
        perform(func_name, tone or "Same as original", language, kwargs)


def subject_form():
    st.caption("Paste your email and get five alternative subject lines.")
    with st.form("subject_form"):
        email_text = st.text_area("Paste your email *", height=220)
        language = st.selectbox("Language", engine.LANGUAGES)
        submitted = st.form_submit_button("🏷️ Generate 5 Subject Lines", type="primary")

    if submitted:
        if not email_text.strip():
            st.warning("Please paste your email first.")
        else:
            options = run_task(
                "Thinking of subject lines...", engine.generate_subject_lines,
                email_text=email_text, language=language,
            )
            if options:
                st.session_state.subject_options = options

    if st.session_state.subject_options:
        st.subheader("Subject line ideas")
        for option in st.session_state.subject_options:
            st.code(option, language=None, wrap_lines=True)


def reply_form():
    st.caption("Paste an email you received and generate a suitable reply.")
    with st.form("reply_form"):
        received = st.text_area("Email you received *", height=200)
        points = st.text_area(
            "What do you want to say in your reply? (optional)", height=100,
            placeholder="e.g. Confirm I can attend, and ask for the agenda in advance.",
        )
        sender = st.text_input("Your name / designation (optional)")
        c1, c2, c3 = st.columns(3)
        tone = c1.selectbox("Tone", engine.TONES)
        length = c2.radio("Length", list(engine.LENGTHS.keys()), index=1, horizontal=True)
        language = c3.selectbox("Language", engine.LANGUAGES)
        submitted = st.form_submit_button("↩️ Generate Reply", type="primary")

    if submitted:
        if not received.strip():
            st.warning("Please paste the email you received.")
            return
        kwargs = {
            "received_email": received, "reply_points": points, "sender": sender,
            "tone": tone, "length": length, "language": language,
        }
        perform("generate_reply", tone, language, kwargs)


# ----------------------------------------------------------------------
# Sidebar and main page
# ----------------------------------------------------------------------
with st.sidebar:
    st.title("✉️ Email Assistant")
    st.write("Create clear, professional email drafts. Nothing is ever sent automatically. You review and copy every draft yourself.")
    st.markdown("**Features**")
    st.markdown("- Generate emails\n- Improve, rewrite, shorten, expand\n- Subject line ideas\n- Reply generator\n- English and Urdu")
    st.markdown("**Model**")
    st.code(engine.DEFAULT_MODEL, language=None)
    st.markdown("**How to use**")
    st.markdown("1. Pick a feature.\n2. Fill in the form.\n3. Click the button.\n4. Review, adjust and copy the draft.")
    st.caption("This app does not save your emails. Avoid pasting highly confidential information.")

st.markdown(STYLE, unsafe_allow_html=True)
st.markdown(HERO, unsafe_allow_html=True)

feature = st.radio("Choose a feature", FEATURES, horizontal=True, label_visibility="collapsed")

if feature == FEATURES[0]:
    generate_form()
elif feature == FEATURES[1]:
    single_email_form("improve_form", "🛠️ Improve Email", "improve_email", False,
                      "Fixes grammar, improves clarity and professionalism, and keeps your meaning.",
                      "Paste your email *")
elif feature == FEATURES[2]:
    single_email_form("rewrite_form", "🔄 Rewrite Email", "rewrite_email", True,
                      "Rewrites your email in a different tone.", "Paste your email *")
elif feature == FEATURES[3]:
    single_email_form("shorten_form", "✂️ Shorten Email", "shorten_email", False,
                      "Turns a long email into a concise one without losing key information.",
                      "Paste your long email *")
elif feature == FEATURES[4]:
    single_email_form("expand_form", "📖 Expand Email", "expand_email", True,
                      "Expands a short message into a full professional email without inventing facts.",
                      "Paste your short message *")
elif feature == FEATURES[5]:
    subject_form()
else:
    reply_form()

if feature != FEATURES[5]:
    show_result()

st.markdown(FOOTER, unsafe_allow_html=True)
