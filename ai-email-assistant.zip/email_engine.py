"""
email_engine.py
All AI logic for the AI Email Writing Assistant.
This file contains NO Streamlit code, so it can be tested on its own.
"""

import re

import groq

DEFAULT_MODEL = "openai/gpt-oss-20b"

PURPOSES = [
    "Business Inquiry", "Follow-up Email", "Job Application", "Meeting Request",
    "Meeting Confirmation", "Thank You Email", "Apology Email", "Complaint Email",
    "Official Correspondence", "Client Communication", "Sales Email", "Project Update",
    "Request for Information", "Reminder Email", "Resignation Email", "General Email",
]

TONES = [
    "Professional", "Formal", "Friendly", "Conversational", "Persuasive",
    "Diplomatic", "Assertive", "Respectful", "Concise",
]

LENGTHS = {
    "Short": "Short: about 60 to 90 words.",
    "Medium": "Medium: about 120 to 180 words.",
    "Detailed": "Detailed: about 220 to 320 words.",
}

LANGUAGES = ["English", "Urdu"]

MAX_INPUT_CHARS = 8000


class EmailEngineError(Exception):
    """An error with a friendly message that is safe to show to users."""


SYSTEM_PROMPT = """You are an experienced professional business-communication specialist. You write emails that read as if a thoughtful person wrote them.

Writing principles:
- Use natural, human language. Avoid robotic or stock AI phrases such as "I hope this email finds you well", "I am writing to express" and "Please do not hesitate to contact me". Do not repeat information.
- Follow the requested tone and length.
- Keep proper email etiquette and respect the recipient's position and the relationship between sender and recipient.
- Get to the point. No unnecessary introductions.
- Use clear, concise sentences and a logical paragraph structure.
- NEVER invent facts, dates, names, numbers, promises, commitments or claims that are not in the information provided. If something essential is missing, write around it or use a short placeholder in square brackets, such as [date].
- Include a suitable greeting and closing. If the sender's name is not given, end with [Your Name]. If the recipient's name is not known, use a neutral greeting.
- The email must be ready to copy and send.
"""

OUTPUT_FORMAT = """Return ONLY the following format, with no commentary and no markdown symbols:
SUBJECT: <one subject line>
BODY:
<the full email from greeting to closing>"""


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def get_client(api_key, timeout=45.0):
    """Create a Groq client. Raises a friendly error if the key is missing."""
    if not api_key or not str(api_key).strip():
        raise EmailEngineError(
            "The Groq API key is missing. Add GROQ_API_KEY to your secrets and try again."
        )
    return groq.Groq(api_key=str(api_key).strip(), timeout=timeout, max_retries=1)


def _clean(value, label="input"):
    text = (value or "").strip()
    if len(text) > MAX_INPUT_CHARS:
        raise EmailEngineError(
            f"The {label} is too long. Please keep it under {MAX_INPUT_CHARS} characters."
        )
    return text


def _require(value, label):
    text = _clean(value, label)
    if not text:
        raise EmailEngineError(f"Please enter {label}.")
    return text


def _check_choice(value, allowed, label):
    if value not in allowed:
        raise EmailEngineError(f"Invalid {label}: {value!r}.")


def _language_rule(language):
    if language == "Urdu":
        return (
            "Write the entire email, including the subject line, in natural, "
            "grammatically correct Urdu (Urdu script). Keep names, email addresses, "
            "numbers and technical terms exactly as given."
        )
    return "Write the email in clear, natural English."


def _call_model(client, system_prompt, user_prompt, model=DEFAULT_MODEL, temperature=0.6):
    """Send one request to Groq and return the text. Converts all errors to friendly ones."""
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
            max_completion_tokens=4096,
            extra_body={"reasoning_effort": "low"},
        )
    except groq.APITimeoutError:
        raise EmailEngineError("The request timed out. Please try again in a moment.")
    except groq.APIConnectionError:
        raise EmailEngineError("Could not reach the AI service. Check your internet connection and try again.")
    except groq.AuthenticationError:
        raise EmailEngineError("The Groq API key is invalid. Please check the key in your secrets.")
    except groq.RateLimitError:
        raise EmailEngineError("Too many requests right now (rate limit reached). Please wait a minute and try again.")
    except groq.NotFoundError:
        raise EmailEngineError(f"The AI model '{model}' was not found. Please check the model name.")
    except groq.PermissionDeniedError:
        raise EmailEngineError("Your Groq account does not have access to this model or action.")
    except groq.BadRequestError:
        raise EmailEngineError("The AI service rejected the request. Check the model name and your input, then try again.")
    except groq.APIStatusError as error:
        raise EmailEngineError(f"The AI service returned an error (code {error.status_code}). Please try again later.")
    except Exception:
        raise EmailEngineError("An unexpected error occurred while contacting the AI service.")

    text = None
    if response.choices:
        text = response.choices[0].message.content
    if not text or not text.strip():
        raise EmailEngineError("The AI returned an empty response. Please try again.")
    return text.strip()


def parse_email(text):
    """Split the AI response into subject and body."""
    text = text.replace("**", "").strip()
    subject_match = re.search(r"^\s*SUBJECT\s*:\s*(.+)$", text, re.IGNORECASE | re.MULTILINE)
    body_match = re.search(r"^\s*BODY\s*:\s*(.*)$", text, re.IGNORECASE | re.MULTILINE | re.DOTALL)

    if subject_match and body_match and body_match.start() >= subject_match.start():
        subject = subject_match.group(1).strip().strip('"').strip()
        body = body_match.group(1).strip()
        if body:
            return subject, body

    # The AI ignored the format: show everything as the body rather than failing.
    return "", text


def _ask(client, user_prompt, model, temperature):
    text = _call_model(client, SYSTEM_PROMPT, user_prompt, model=model, temperature=temperature)
    subject, body = parse_email(text)
    return {"subject": subject, "body": body}


# ----------------------------------------------------------------------
# Feature 1: Generate Email
# ----------------------------------------------------------------------
def generate_email(client, purpose, recipient, sender="", subject="", context="",
                   tone="Professional", length="Medium", language="English",
                   additional="", model=DEFAULT_MODEL):
    """Create a complete email from the user's details. Returns {"subject", "body"}."""
    recipient = _require(recipient, "the recipient")
    context = _require(context, "the email context (what you want to say)")
    sender = _clean(sender, "sender information")
    subject = _clean(subject, "subject")
    additional = _clean(additional, "additional instructions")
    _check_choice(purpose, PURPOSES, "email purpose")
    _check_choice(tone, TONES, "tone")
    _check_choice(length, list(LENGTHS), "length")
    _check_choice(language, LANGUAGES, "language")

    subject_line = (
        f"Use exactly this subject: {subject}" if subject
        else "Not provided. Write a clear, meaningful subject line."
    )

    prompt = f"""Write an email using the details below.

Purpose: {purpose}
Recipient: {recipient}
Sender: {sender or "Not provided"}
Subject: {subject_line}
Tone: {tone}
Length: {LENGTHS[length]}
Language rule: {_language_rule(language)}

What the sender wants to communicate:
{context}

Additional instructions from the user:
{additional or "None"}

{OUTPUT_FORMAT}"""

    return _ask(client, prompt, model, temperature=0.6)


# ----------------------------------------------------------------------
# Feature 2: Improve Existing Email
# ----------------------------------------------------------------------
def improve_email(client, email_text, language="English", model=DEFAULT_MODEL):
    """Fix grammar, clarity and professionalism without changing the meaning."""
    email_text = _require(email_text, "the email you want to improve")
    _check_choice(language, LANGUAGES, "language")

    prompt = f"""Improve the email below.

Do all of the following:
- Correct grammar, spelling and punctuation.
- Improve sentence structure and clarity.
- Make it more professional.
- Remove unnecessary words.
- Keep the original meaning, facts, names, dates and commitments exactly. Do not add new information.

Language rule: {_language_rule(language)}

If the email has a subject line, keep it (improve it only if it is unclear). If it has none, write a suitable one.

--- EMAIL START ---
{email_text}
--- EMAIL END ---

{OUTPUT_FORMAT}"""

    return _ask(client, prompt, model, temperature=0.3)


# ----------------------------------------------------------------------
# Feature 3: Rewrite Email in a different tone
# ----------------------------------------------------------------------
def rewrite_email(client, email_text, tone="Professional", language="English", model=DEFAULT_MODEL):
    email_text = _require(email_text, "the email you want to rewrite")
    _check_choice(tone, TONES, "tone")
    _check_choice(language, LANGUAGES, "language")

    prompt = f"""Rewrite the email below in a {tone} tone.

Keep the same meaning, facts, names, dates and commitments. Do not add new information.
Language rule: {_language_rule(language)}
If the email has a subject line, keep it unless it no longer fits the new tone. If it has none, write one.

--- EMAIL START ---
{email_text}
--- EMAIL END ---

{OUTPUT_FORMAT}"""

    return _ask(client, prompt, model, temperature=0.5)


# ----------------------------------------------------------------------
# Feature 4: Shorten Email
# ----------------------------------------------------------------------
def shorten_email(client, email_text, language="English", model=DEFAULT_MODEL):
    email_text = _require(email_text, "the email you want to shorten")
    _check_choice(language, LANGUAGES, "language")

    prompt = f"""Shorten the email below into a concise, effective message.

Cut filler and repetition, but keep every important fact, date, request and commitment.
Do not add new information. Keep the original tone.
Language rule: {_language_rule(language)}
If the email has a subject line, keep it. If it has none, write one.

--- EMAIL START ---
{email_text}
--- EMAIL END ---

{OUTPUT_FORMAT}"""

    return _ask(client, prompt, model, temperature=0.3)


# ----------------------------------------------------------------------
# Feature 5: Expand Email
# ----------------------------------------------------------------------
def expand_email(client, email_text, tone="Professional", language="English", model=DEFAULT_MODEL):
    email_text = _require(email_text, "the short message you want to expand")
    _check_choice(tone, TONES, "tone")
    _check_choice(language, LANGUAGES, "language")

    prompt = f"""Expand the short message below into a complete, detailed professional email in a {tone} tone.

Add proper greeting, structure and closing, and explain the points more fully.
Do NOT invent facts, dates, names, reasons or commitments. Use only what the message says; use a placeholder in square brackets for any missing essential detail.
Language rule: {_language_rule(language)}

--- MESSAGE START ---
{email_text}
--- MESSAGE END ---

{OUTPUT_FORMAT}"""

    return _ask(client, prompt, model, temperature=0.5)


# ----------------------------------------------------------------------
# Feature 6: Generate Subject Lines
# ----------------------------------------------------------------------
def generate_subject_lines(client, email_text, language="English", model=DEFAULT_MODEL):
    """Return a list of five alternative subject lines."""
    email_text = _require(email_text, "the email content")
    _check_choice(language, LANGUAGES, "language")

    prompt = f"""Write exactly 5 different subject lines for the email below.
Make them clear, specific and natural. Vary the style a little. Do not invent facts.
Language rule: {_language_rule(language)}

--- EMAIL START ---
{email_text}
--- EMAIL END ---

Return ONLY the 5 subject lines, one per line, with no numbering, no quotes and no commentary."""

    text = _call_model(client, SYSTEM_PROMPT, prompt, model=model, temperature=0.8)

    lines = []
    for raw in text.replace("**", "").splitlines():
        line = re.sub(r"^\s*(?:[-*•]|\d+[.):-])\s*", "", raw).strip().strip('"').strip()
        if line:
            lines.append(line)

    if not lines:
        raise EmailEngineError("The AI did not return any subject lines. Please try again.")
    return lines[:5]


# ----------------------------------------------------------------------
# Feature 7: Email Reply Generator
# ----------------------------------------------------------------------
def generate_reply(client, received_email, reply_points="", sender="", tone="Professional",
                   length="Medium", language="English", model=DEFAULT_MODEL):
    received_email = _require(received_email, "the email you received")
    reply_points = _clean(reply_points, "reply points")
    sender = _clean(sender, "sender information")
    _check_choice(tone, TONES, "tone")
    _check_choice(length, list(LENGTHS), "length")
    _check_choice(language, LANGUAGES, "language")

    prompt = f"""Write a reply to the email below.

Sender of the reply: {sender or "Not provided"}
Tone: {tone}
Length: {LENGTHS[length]}
Language rule: {_language_rule(language)}

What the user wants to say in the reply:
{reply_points or "Not specified. Write a suitable, polite reply that answers the questions or requests in the received email, without making any commitments the user did not state."}

Use "Re: <original subject>" as the subject if the original has a subject.
Answer what the received email asks. Do not invent facts, dates or commitments.

--- RECEIVED EMAIL START ---
{received_email}
--- RECEIVED EMAIL END ---

{OUTPUT_FORMAT}"""

    return _ask(client, prompt, model, temperature=0.5)
