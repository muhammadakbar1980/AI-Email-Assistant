# AI Email Writing Assistant

Write professional, clear and effective emails in seconds with AI.
Built with Python, Streamlit and the Groq API (default model: `openai/gpt-oss-20b`).

## Features

- Generate emails for 16 purposes (business, job application, follow-up, complaint and more)
- Improve, rewrite, shorten and expand existing emails
- Generate five alternative subject lines
- Reply generator for emails you have received
- Nine tones, three lengths, English and Urdu
- Drafts only: the app never sends email or accesses your mailbox

## Project structure

    ai-email-assistant/
    ├── app.py              Streamlit interface
    ├── email_engine.py     AI logic (Groq)
    ├── requirements.txt
    ├── README.md
    ├── .gitignore
    └── .streamlit/
        └── config.toml     Theme (no secrets)

## Run locally

1. Install Python 3.10 or newer.
2. Install dependencies: `pip install -r requirements.txt`
3. Get a free API key at https://console.groq.com
4. Create the file `.streamlit/secrets.toml` with this line:

        GROQ_API_KEY = "your_actual_groq_api_key"

5. Start the app: `streamlit run app.py`

Never commit `.streamlit/secrets.toml` to GitHub. It is listed in `.gitignore`.

## Deploy on Streamlit Community Cloud

1. Push this project to a GitHub repository.
2. Go to https://share.streamlit.io and sign in with GitHub.
3. Click Create app, pick the repository, branch `main`, and main file `app.py`.
4. Open Advanced settings, then Secrets, and paste:

        GROQ_API_KEY = "your_actual_groq_api_key"

5. Click Deploy.

## Security

- The API key is read from Streamlit Secrets, never from the source code.
- The app does not store email contents.
- Do not paste highly confidential information into any AI tool.

Powered by Groq AI | Built with Python and Streamlit
